// MIT License
// (License text)
// MIT License
// (License text)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;

public class OfflineMapbox : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
    // Public variables for configuring the map
    public float centerLatitude = 25.2048f; // Center of Dubai
    public float centerLongitude = 55.2708f; // Center of Dubai
    public float zoom = 12;
    public float dragSpeed = 0.1f;

    private string localTilePathTemplate = "tiles\\{z}\\{x}\\{y}.png";
    private Vector2 initialMousePosition;
    private Vector2 finalMousePosition;
    private Vector2 changeInPosition;
    private RawImage rawImage;

    void Start() {
        // Get the RawImage component
        rawImage = gameObject.GetComponent<RawImage>();
        StartCoroutine(UpdateMap());
    }

    public void OnBeginDrag(PointerEventData eventData) {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData) {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;
    }

    public void OnEndDrag(PointerEventData eventData) {
        StartCoroutine(UpdateMap());
    }

    IEnumerator UpdateMap() {
        int z = Mathf.FloorToInt(zoom);
        int x = Mathf.FloorToInt((float)((centerLongitude + 180.0f) / 360.0f * (1 << z)));
        int y = Mathf.FloorToInt((float)((1.0f - Mathf.Log(Mathf.Tan(centerLatitude * Mathf.Deg2Rad) + 1.0f / Mathf.Cos(centerLatitude * Mathf.Deg2Rad)) / Mathf.PI) / 2.0f * (1 << z)));

        string filePath = localTilePathTemplate.Replace("{z}", z.ToString()).Replace("{x}", x.ToString()).Replace("{y}", y.ToString());
        //string filePath = "5";

        if (File.Exists(filePath)) {
            byte[] fileData = File.ReadAllBytes(filePath);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(fileData);
            rawImage.texture = texture;
        }
        else {
            Debug.Log("Tile not found: " + filePath);
        }

        yield return null;
    }
}

/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;

public class OfflineMapbox : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
    // Public variables for configuring the map
    public float centerLatitude = 25.2048f; // Center of Dubai
    public float centerLongitude = 55.2708f; // Center of Dubai
    public float zoom = 12;
    public float dragSpeed = 0.1f;

    private string localTilePathTemplate = "tiles/{z}/{x}/{y}.png";
    private Vector2 initialMousePosition;
    private Vector2 finalMousePosition;
    private Vector2 changeInPosition;
    private RawImage rawImage;

    void Start() {
        // Get the RawImage component
        rawImage = gameObject.GetComponent<RawImage>();
        StartCoroutine(UpdateMap());
    }

    public void OnBeginDrag(PointerEventData eventData) {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData) {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;
    }

    public void OnEndDrag(PointerEventData eventData) {
        StartCoroutine(UpdateMap());
    }

    IEnumerator UpdateMap() {
        int z = Mathf.FloorToInt(zoom);
        int x = Mathf.FloorToInt((float)((centerLongitude + 180.0f) / 360.0f * (1 << z)));
        int y = Mathf.FloorToInt((float)((1.0f - Mathf.Log(Mathf.Tan(centerLatitude * Mathf.Deg2Rad) + 1.0f / Mathf.Cos(centerLatitude * Mathf.Deg2Rad)) / Mathf.PI) / 2.0f * (1 << z)));

        string filePath = localTilePathTemplate.Replace("{z}", z.ToString()).Replace("{x}", x.ToString()).Replace("{y}", y.ToString());

        if (File.Exists(filePath)) {
            byte[] fileData = File.ReadAllBytes(filePath);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(fileData);
            rawImage.texture = texture;
        }
        else {
            Debug.LogWarning("Tile not found: " + filePath);
        }

        yield return null;
    }
}
*/

// MIT License
// (License text)
/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;

public class OfflineMapbox : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
    /*
    public float centerLatitude = 25.2048f; // Center of Dubai
    public float centerLongitude = 55.2708f; // Center of Dubai
    public float zoom = 12;
    public float dragSpeed = 0.1f;

    private string localTilePathTemplate = "tiles/{z}/{x}/{y}.png";
    private Vector2 initialMousePosition;
    private Vector2 finalMousePosition;
    private Vector2 changeInPosition;
    private Rect rect;
    private RawImage rawImage;

    void Start() {
        rawImage = gameObject.GetComponent<RawImage>();
        rect = rawImage.rectTransform.rect;
        StartCoroutine(UpdateMap());
    }

    public void OnBeginDrag(PointerEventData eventData) {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData) {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;
    }

    public void OnEndDrag(PointerEventData eventData) {
        StartCoroutine(UpdateMap());
    }
    */

// Start is called before the first frame update

/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;


string accessToken = "pk.eyJ1IjoidG9yZ2l1cy11bm9mZmljaWFsIiwiYSI6ImNseGVyYW9wYTBodmwycXF6cGR1Mjg2YWcifQ.a0rZ1_XzjE6NYdOBH6N82g";
    public float centerLatitude;
    public float centerLongitude;
    public float zoom;
    public int bearing;
    public int pitch;
    public enum style { Light, Dark, Streets, Outdoors, Satellite, SatelliteStreets };
    public style mapStyle = style.Streets;
    public enum resolution { low = 1, high = 2 };
    public resolution mapResolution = resolution.low;

    private int mapWidth = 800;
    private int mapHeight = 600;

    private string[] styleStr = new string[] { "light-v10", "dark-v10", "streets-v11", "outdoors-v11", "satellite-v9", "satellite-streets-v11" };
    private string url = "";
    private bool mapIsLoading = false;
    private Rect rect;
    private bool updateMap = true;

    private string accessTokenLast;
    private float centerLatitudeLast = -33.8873f;
    private float centerLongitudeLast = 151.2189f;
    private float zoomLast = 12.0f;
    private int bearingLast = 0;
    private int pitchLast = 0;
    private style mapStyleLast = style.Streets;
    private resolution mapResolutionLast = resolution.low;
    private Vector2 initialMousePosition;
    private Vector2 finalMousePosition;
    private Vector2 connectedVariable;
    private Vector2 changeInPosition;
    public float dragSpeed;

    public float updateInterval = 0.5f;
    public float lastUpdateTime;
    public bool isDragging = false;
    public bool isMapUpdated = false;

    private string localTilePathTemplate = "tiles/{z}/{x}/{y}.png";

    private Rect rectt;
    private RawImage rawImage;


    void Start() {
        //rawImage = gameObject.GetComponent<RawImage>().rectTransform.rect;
        rawImage = gameObject.GetComponent<RawImage>();
        rectt = rawImage.rectTransform.rect;
        StartCoroutine(UpdateMap());
    }

    /*
    // Update is called once per frame
    void Update() {
        if (updateMap && (accessTokenLast != accessToken || !Mathf.Approximately(centerLatitudeLast, centerLatitude) || !Mathf.Approximately(centerLongitudeLast, centerLongitude) || zoomLast != zoom || bearingLast != bearing || pitchLast != pitch || mapStyleLast != mapStyle || mapResolutionLast != mapResolution)) {
            rawImage = gameObject.GetComponent<RawImage>().rectTransform.rect;
            StartCoroutine(UpdateMap());

        }
    }
    */

/*
    public void OnBeginDrag(PointerEventData eventData) {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData) {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;
    }

    public void OnEndDrag(PointerEventData eventData) {
        StartCoroutine(UpdateMap());
    }



    IEnumerator UpdateMap() {
        int z = Mathf.FloorToInt(zoom);
        int x = Mathf.FloorToInt((float)((centerLongitude + 180.0f) / 360.0f * (1 << z)));
        int y = Mathf.FloorToInt((float)((1.0f - Mathf.Log(Mathf.Tan(centerLatitude * Mathf.Deg2Rad) + 1.0f / Mathf.Cos(centerLatitude * Mathf.Deg2Rad)) / Mathf.PI) / 2.0f * (1 << z)));

        string filePath = localTilePathTemplate.Replace("{z}", z.ToString()).Replace("{x}", x.ToString()).Replace("{y}", y.ToString());

        if (File.Exists(filePath)) {
            byte[] fileData = File.ReadAllBytes(filePath);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(fileData);
            rawImage.texture = texture;
        }
        else {
            Debug.log("Tile not found: " + filePath);
        }

        yield return null;
    }

}
*/
