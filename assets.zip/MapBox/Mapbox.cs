
//MIT License
//Copyright (c) 2023 DA LAB (https://www.youtube.com/@DA-LAB)
//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:
//The above copyright notice and this permission notice shall be included in all
//copies or substantial portions of the Software.
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//SOFTWARE.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.Networking;
using System;
using TMPro;

public class Mapbox : MonoBehaviour, IBeginDragHandler, IDragHandler
{
    string accessToken = "pk.eyJ1IjoidG9yZ2l1cy11bm9mZmljaWFsIiwiYSI6ImNseGVyYW9wYTBodmwycXF6cGR1Mjg2YWcifQ.a0rZ1_XzjE6NYdOBH6N82g";
    public float centerLatitude;
    public float centerLongitude;
    public float zoom;
    public int bearing;
    public int pitch;
    public enum style { Light, Dark, Streets, Outdoors, Satellite, SatelliteStreets };
    public style mapStyle = style.Streets;
    public enum resolution { low = 1, high = 2 };
    public resolution mapResolution = resolution.low;

    private int mapWidth = 800;
    private int mapHeight = 600;

    private string[] styleStr = new string[] { "light-v10", "dark-v10", "streets-v11", "outdoors-v11", "satellite-v9", "satellite-streets-v11" };
    private string url = "";
    private bool mapIsLoading = false; 
    private Rect rect;
    private bool updateMap = true;

    private string accessTokenLast;
    private float centerLatitudeLast = -33.8873f;
    private float centerLongitudeLast = 151.2189f;
    private float zoomLast = 12.0f;
    private int bearingLast = 0;
    private int pitchLast = 0;
    private style mapStyleLast = style.Streets;
    private resolution mapResolutionLast = resolution.low;
    private Vector2 initialMousePosition;
    private Vector2 finalMousePosition;
    private Vector2 connectedVariable;
    private Vector2 changeInPosition;
    public float dragSpeed;

    public float updateInterval = 0.5f; 
    public float lastUpdateTime;
    public bool isDragging = false;
    public bool isMapUpdated = false;
    private float rotationSpeed = 500.0f;
    private Vector3 mouseWorldPosStart;
    private float zoomScale = 50.0f;
    private float zoomMin = 0.5f;
    private float zoomMax = 1000.0f;
    public TextMeshProUGUI loadingText; //Text to show while map is loading
    private int framesSinceMapLoaded = 0;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(GetMapbox());
        rect = gameObject.GetComponent<RawImage>().rectTransform.rect;
    }

    // Update is called once per frame
    void Update()
    {
        Zoom(Input.GetAxis("Mouse ScrollWheel"));
        if (mapIsLoading)
        {
            loadingText.gameObject.SetActive(true);
        }
        if (updateMap && (accessTokenLast != accessToken || !Mathf.Approximately(centerLatitudeLast, centerLatitude) || !Mathf.Approximately(centerLongitudeLast, centerLongitude) || zoomLast != zoom || bearingLast != bearing || pitchLast != pitch || mapStyleLast != mapStyle || mapResolutionLast != mapResolution))
        {
            rect = gameObject.GetComponent<RawImage>().rectTransform.rect;
            updateMap = false;
            StartCoroutine(GetMapbox());

        }
    }
    void Zoom(float zoomDiff)
    {
        if (zoomDiff != 0)
        {
            mouseWorldPosStart = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Camera.main.orthographicSize = Mathf.Clamp(Camera.main.orthographicSize - zoomDiff * zoomScale, zoomMin, zoomMax);
            Vector3 mouseWorldPosDiff = mouseWorldPosStart - Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position += mouseWorldPosDiff;
        }
    }
    IEnumerator GetMapbox()
    {
        if (mapIsLoading) {
            yield break;
		}

        //url = "https://api.mapbox.com/styles/v1/mapbox/" + styleStr[(int)mapStyle] + "/static/" + centerLongitude + "," + centerLatitude + "," + zoom + "," + bearing + "," + pitch + "/" + mapWidth + "x" + mapHeight + "?" + "access_token=" + accessToken;
        url = "https://api.mapbox.com/styles/v1/mapbox/" + styleStr[(int)mapStyle] + "/static/" + centerLongitude + "," + centerLatitude + "," + zoom + "," + bearing + "," + pitch + "/" + mapWidth + "x" + mapHeight + "?" + "access_token=" + accessToken;
        mapIsLoading = true;
        UnityWebRequest www = UnityWebRequestTexture.GetTexture(url);
        yield return www.SendWebRequest();
        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.Log("Request URL: " + url);
            Debug.Log("Center Latitude: " + centerLatitude);
            Debug.Log("Center Longitude: " + centerLongitude);
            Debug.Log("Zoom: " + zoom);
            Debug.Log("Bearing: " + bearing);
            Debug.Log("Pitch: " + pitch);
            Debug.Log("Map Width: " + mapWidth);
            Debug.Log("Map Height: " + mapHeight);
            Debug.Log("Map Style: " + styleStr[(int)mapStyle]);
            Debug.Log("Access Token: " + accessToken);
            Debug.Log("WWW ERROR: " + www.error);
        }
        else
        {
            //mapIsLoading = false;
            gameObject.GetComponent<RawImage>().texture = ((DownloadHandlerTexture)www.downloadHandler).texture;

            accessTokenLast = accessToken;
            centerLatitudeLast = centerLatitude;
            centerLongitudeLast = centerLongitude;
            zoomLast = zoom;
            bearingLast = bearing;
            pitchLast = pitch;
            mapStyleLast = mapStyle;
            mapResolutionLast = mapResolution;
            updateMap = true;
            isMapUpdated = true;
        }
        mapIsLoading = false;
    }

    public void OnBeginDrag(PointerEventData eventData) {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        isDragging = true;
    }

    public void OnDrag(PointerEventData eventData) {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;

        /*
        if (Time.time - lastUpdateTime > updateInterval) {
            lastUpdateTime = Time.time;
            StartCoroutine(GetMapbox());
        }
        */
    }

    public void OnEndDrag(PointerEventData eventData) {
        isDragging = false;
        StartCoroutine(GetMapbox());
    }

    void LateUpdate() {
        if (isDragging && Time.time - lastUpdateTime > updateInterval && !mapIsLoading) {
            lastUpdateTime = Time.time;
            StartCoroutine(GetMapbox());
        }
    }

    /*
    public void OnBeginDrag(PointerEventData eventData)
    {
        initialMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData)
    {
        finalMousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        changeInPosition = finalMousePosition - initialMousePosition;
        centerLongitude -= changeInPosition.x * dragSpeed;
        centerLatitude -= changeInPosition.y * dragSpeed;
        initialMousePosition = finalMousePosition;
        StartCoroutine(GetMapbox());
    }
    */
}
