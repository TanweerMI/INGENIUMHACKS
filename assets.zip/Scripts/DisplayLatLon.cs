using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Unity.VisualScripting;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class DisplayLatLon : MonoBehaviour
{
    public Text latCo;
    public Text lonCo;

    // Update is called once per frame
    public void MarkerInfoPull(int i)
    {
        string[] latitudeLines = File.ReadAllLines(Application.dataPath + "/Texts/Latitude.txt");
        string[] longitudeLines = File.ReadAllLines(Application.dataPath + "/Texts/Longitude.txt");
        latCo.text = Convert.ToString(latitudeLines[i]);
        lonCo.text = Convert.ToString(longitudeLines[i]);
    }
}
