using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.SearchService;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class OnButtonClick : MonoBehaviour
{
    public void TakeMeToMap()
    {
        SceneManager.LoadScene(0);
    }
}
