using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System;
using TMPro;

public class ButtonNumber : MonoBehaviour
{
    public int markerNumber;
    public TextMeshProUGUI childText;
    public DisplayLatLon latLon;
    public Text notes;

    private void Start()
    {
        childText = gameObject.GetComponentInChildren<TextMeshProUGUI>();
        latLon = FindAnyObjectByType<DisplayLatLon>();
        string[] markerTitles = File.ReadAllLines(Application.dataPath + "/Texts/MarkerTitles.txt");
        if (markerTitles[markerNumber] != null)
        {
            childText.text = markerTitles[markerNumber];
        }
    }

    public void Entree()
    {
        MarkerInfoPull(markerNumber);
    }

    public void MarkerInfoPull(int i)
    {

        string[] markerTexts = File.ReadAllLines(Application.dataPath + "/Texts/MarkerText.txt");
        notes.text = markerTexts[i];
        latLon.MarkerInfoPull(i);
    }

}
