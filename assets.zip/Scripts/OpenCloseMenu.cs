using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenCloseMenu : MonoBehaviour
{
    public GameObject menu;
    private float exitPos = -731f;
    private float openPos = 0f;
    public float speed = 50f;

    public void Close()
    {
        StartCoroutine(Closing());
    }

    public void Open()
    {
        StartCoroutine(Opening());
    }

    IEnumerator Closing()
    {
        while (menu.transform.position.x >= exitPos)
        {
            menu.transform.Translate(-1f * speed, 0, 0);
            yield return new WaitForSeconds(0.01f);
            if (menu.transform.position.x <= exitPos)
            {
                menu.transform.localPosition = new Vector2(exitPos, 0);
                break;
            }
        }
    }
    IEnumerator Opening()
    {
        while (true)
        {
            menu.transform.Translate(1f * speed, 0, 0);
            yield return new WaitForSeconds(0.01f);
            if (menu.transform.position.x >= openPos)
            {
                menu.transform.localPosition = new Vector2(openPos, 0);
                break;
            }
        }
    }
}
