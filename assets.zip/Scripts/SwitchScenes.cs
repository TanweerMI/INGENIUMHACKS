using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchScenes : MonoBehaviour
{
    public void Maps()
    {
        SceneManager.LoadScene(0);
    }

    public void Pokedex()
    {
        SceneManager.LoadScene(1);
    }
}
