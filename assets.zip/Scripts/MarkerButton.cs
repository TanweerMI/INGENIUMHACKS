using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using TMPro;
using System;
public class MarkerButton : MonoBehaviour
{
    public GameObject Marker;
    public GameObject Finalise;
    public double centerLat;
    public double centerLong;
    private List<string> finalLatitudeInfo = new List<string>();
    private List<string> finalLongitudeInfo = new List<string>();
    private List<double> latitudeArrayInitial = new List<double>();
    private List<double> longitudeArrayInitial = new List<double>();
    private List<string> markerTitleArray = new List<string>();
    private List<string> markerTextArray = new List<string>();
    public TextMeshProUGUI LatitudeText;
    public TextMeshProUGUI LongitudeText;
    public TextMeshProUGUI markerTitleText;
    public TextMeshProUGUI markerText;
    public bool isClickFinal = false;
    public MapControl centerCoords;
    public GameObject titleSomething;
    public GameObject textSomething;
    public TMP_InputField markerTitleInputField;
    public TMP_InputField markerTxtInputField;
    //public double centerLatt;
    //public double centerLongg;

    // Start is called before the first frame update
    void Start() {

        centerCoords = FindObjectOfType<MapControl>();

        string[] latitudeLines = File.ReadAllLines(Application.dataPath + "/Texts/Latitude.txt");
        foreach (string line in latitudeLines) {
            latitudeArrayInitial.Add(Convert.ToDouble(line));
        }

        string[] longitudeLines = File.ReadAllLines(Application.dataPath + "/Texts/Longitude.txt");
        foreach (string line in longitudeLines) {
            longitudeArrayInitial.Add(Convert.ToDouble(line));
        }

        string[] markerTitles = File.ReadAllLines(Application.dataPath + "/Texts/MarkerTitles.txt");
        markerTitleArray.AddRange(markerTitles);

        string[] markerTexts = File.ReadAllLines(Application.dataPath + "/Texts/MarkerText.txt");
        markerTextArray.AddRange(markerTexts);

        /*
        latitudeArrayInitial = Convert.ToDouble(File.ReadAllLines(Application.dataPath + "/Texts/Latitude.txt"));
        longitudeArrayInitial = Convert.ToDouble(File.ReadAllLines(Application.dataPath + "/Texts/Longitude.txt"));
        markerTitleArray = File.ReadAllLines(Application.dataPath + "/Texts/MarkerTitles.txt");
        markerTextArray = File.ReadAllLines(Application.dataPath + "/Texts/MarkerText.txt");
        */
    }
    public void OnClickMarker()
    {
        titleSomething.SetActive(true);
        textSomething.SetActive(true);
        Marker.SetActive(true);
        Finalise.SetActive(true);
    }
    public void MarkerInfoPull(int i)
    {
        LatitudeText.text = Convert.ToString(latitudeArrayInitial[i]);
        LongitudeText.text = Convert.ToString(longitudeArrayInitial[i]);
        markerTitleText.text = markerTitleArray[i];
        markerText.text = markerTextArray[i];
    }
    public void OnClickFinal() {
        isClickFinal = true;
        Marker.SetActive(false);
        Finalise.SetActive(false);
        titleSomething.SetActive(false);
        textSomething.SetActive(false);

        //this part causes null reference exception probably coz it has nothing yet. uncomment when there is something
        //markerTitleArray.Add(markerTitleText.text);
        //markerTextArray.Add(markerText.text);

        markerTitleArray.Add(markerTitleInputField.text);
        markerTextArray.Add(markerTxtInputField.text);

        centerLat = centerCoords.centerLatitude;
        centerLong = centerCoords.centerLongitude;

        Debug.Log(markerTitleArray);
        Debug.Log(markerTextArray);
        Debug.Log(centerLat);
        Debug.Log(centerLong);

        latitudeArrayInitial.Add(centerLat);
        foreach (double line in latitudeArrayInitial)
        {
            finalLatitudeInfo.Add(Convert.ToString(line));
        }
        longitudeArrayInitial.Add(centerLong);
        foreach (double line in longitudeArrayInitial)
        {
            finalLongitudeInfo.Add(Convert.ToString(line));
        }

        File.WriteAllLines(Application.dataPath + "/Texts/Latitude.txt", finalLatitudeInfo);
        File.WriteAllLines(Application.dataPath + "/Texts/Longitude.txt", finalLongitudeInfo);
        File.WriteAllLines(Application.dataPath + "/Texts/MarkerTitles.txt", markerTitleArray);
        File.WriteAllLines(Application.dataPath + "/Texts/MarkerText.txt", markerTextArray);

        isClickFinal = false;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
